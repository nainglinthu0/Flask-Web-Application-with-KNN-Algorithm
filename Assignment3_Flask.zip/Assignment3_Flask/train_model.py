import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
import joblib

file_path = r'C:\Users\Administrator\Desktop\Personal_NAING\Parami_Naing\Advance Machine Learning\Assignment3_Flask\laptops_dataset_final_600.csv'
df = pd.read_csv(file_path)

df['sentiment'] = df['rating'].apply(lambda x: 1 if x >= 4 else 0) 

df['review'] = df['review'].str.lower() 
df['review'] = df['review'].str.replace(r'[^\w\s]', '', regex=True)

vectorizer = CountVectorizer(max_features=5000, stop_words='english')
X = vectorizer.fit_transform(df['review']).toarray() 
y = df['sentiment'] 

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)


knn = KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train, y_train)

joblib.dump(knn, 'knn_model.pkl')
joblib.dump(vectorizer, 'count_vectorizer.pkl')

print("KNN model trained and saved!")